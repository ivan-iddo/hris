<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

require APPPATH . '/libraries/REST_Controller.php';
require_once 'include/cryptojs-aes.php';
require_once 'Monitoring.php'; 
$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);
 
/*
 * Changes:
 * 1. This project contains .htaccess file for windows machine.
 *    Please update as per your requirements.
 *    Samples (Win/Linux): http://stackoverflow.com/questions/28525870/removing-index-php-from-url-in-codeigniter-on-mandriva
 *
 * 2. Change 'encryption_key' in application\config\config.php
 *    Link for encryption_key: http://jeffreybarke.net/tools/codeigniter-encryption-key-generator/
 * 
 * 3. Change 'jwt_key' in application\config\jwt.php
 *
 */

class Master extends REST_Controller
{
    /**
     * URL: http://localhost/CodeIgniter-JWT-Sample/auth/token
     * Method: GET
     */
    public function token_get()
    {
        $tokenData = array();
        $tokenData['data'] = array('user_id'=>'1','date'=>date('Y-m-d H:i:s')); //TODO: Replace with data for token
        $output['token'] = AUTHORIZATION::generateToken($tokenData);
        $this->set_response($output, REST_Controller::HTTP_OK);
    }
	
	
	 
public function kelamin_get(){
	$headers = $this->input->request_headers();

        if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
            $decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
            if ($decodedToken != false) {
				 $this->db->order_by('id','ASC');
				  $this->db->where('tampilkan','1');
		  $res = $this->db->get('m_kelamin')->result();
		  foreach($res as $d){
			$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
		  }
		  
		  $this->set_response($arr, REST_Controller::HTTP_OK);
			
                return;
			}
		}
		
		 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
}

public function agama_get(){
	$headers = $this->input->request_headers();

        if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
            $decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
            if ($decodedToken != false) {
				 $this->db->order_by('id_agama','ASC');
				 $this->db->where('aktif','1');
		  $res = $this->db->get('m_agama')->result();
		  foreach($res as $d){
			$arr['result'][]=array('label'=>$d->agama,'value'=>$d->id_agama);
		  }
		  
		  $this->set_response($arr, REST_Controller::HTTP_OK);
			
                return;
			}
		}
		
		 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
}

	public function pendidikan_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('id','ASC');
					 $this->db->where('aktif','1');
			  $res = $this->db->get('m_pendidikan')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function provinsi_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('province_name','ASC'); 
			  $res = $this->db->get('m_provinsi')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->province_name,'value'=>$d->province_id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function kota_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('kota','ASC');
					 if(!empty($idprov = $this->uri->segment(3))){
						$this->db->where('province_id',$idprov);
					 }
			  $res = $this->db->get('m_kota')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->kota,'value'=>$d->id_kota);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function kecamatan_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('kecamatan','ASC');
					 if(!empty($idprov = $this->uri->segment(3))){
						$this->db->where('id_kota',$idprov);
					 }
			  $res = $this->db->get('m_kecamatan')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->kecamatan,'value'=>$d->id_kecamatan);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	
	public function kelurahan_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('kelurahan','ASC');
					 if(!empty($idprov = $this->uri->segment(3))){
						$this->db->where('id_kecamatan',$idprov);
					 }
			  $res = $this->db->get('m_kelurahan')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->kelurahan,'value'=>$d->id_kelurahan);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function status_pegawai_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {

					if(!empty($this->input->get('type'))){
						if($this->input->get('type')=='pns'){
							$this->db->where('id <=','2');
						}

						if($this->input->get('type')=='nonpns'){
							$this->db->where('id >','2');
						}
						
					}
					 $this->db->order_by('nama','ASC');
					 
			  $res = $this->db->get('m_status_pegawai')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}

	 
	
	public function direktorat_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('grup','ASC');
					 $this->db->where('tampilkan','1');
					  $this->db->where('child','27');
			  $res = $this->db->get('sys_grup_user')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->grup,'value'=>$d->id_grup);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function direktoratSub_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('grup','ASC');
					 $this->db->where('tampilkan','1');
					 if(!empty($id = $this->uri->segment(3))){
					  $this->db->where('child',$id);
					 }
			  $res = $this->db->get('sys_grup_user')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->grup,'value'=>$d->id_grup);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function jabatan_asn_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('nama','ASC');
					 $this->db->where('tampilkan','1');
					 
			  $res = $this->db->get('m_jabatan_asn')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function jabatan_struktural_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('nama','ASC');
					 $this->db->where('tampilkan','1');
					 
			  $res = $this->db->get('uk_master')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama.' [Kode: '.$d->id.']','value'=>$d->id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function golongan_pegawai_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('nama','ASC');
					 $this->db->where('tampilkan','1');
					 
			  $res = $this->db->get('m_golongan_pegawai')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function pekerjaan_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('id','ASC');
					 $this->db->where('aktif','1');
			  $res = $this->db->get('m_pekerjaan')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function hubkeluarga_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('id','ASC');
					 $this->db->where('aktif','1');
			  $res = $this->db->get('m_hubungan_keluarga')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
	
	public function statuslulus_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('id','ASC');
					 $this->db->where('tampilkan','1');
			  $res = $this->db->get('m_status_lulus')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}

	public function penanggung_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('id','ASC');
					 $this->db->where('aktif','1');
			  $res = $this->db->get('m_penanggung')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}

	public function jenis_cuti_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				if ($decodedToken != false) {
					 $this->db->order_by('id','ASC');
					 $this->db->where('tampilkan','1');
			  $res = $this->db->get('m_jenis_cuti')->result();
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
			  }
			  
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}

	public function getmaster_get(){
		$headers = $this->input->request_headers();

        if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
            $decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
            if ($decodedToken != false) {
				$id = $this->input->get('id');
				if(!empty($id)){
					 $this->db->where('dm_term.child',$this->input->get('id'));
				}
				  
				  $this->db->select('dm_term.*,dm_taxonomy.nama as nama_grup');
				  $this->db->where('dm_term.tampilkan','1');
				  $this->db->join('dm_taxonomy',' dm_taxonomy.id = dm_term.child');
				  $res = $this->db->get('dm_term')->result();
				  
			if(!empty($res)){
				 foreach($res as $d){
					$arr['result'][]=array('label'=>$d->nama,'value'=>$d->id);
				  }
			}else{
			$arr['result'] ='empty';
		  }
		  $this->set_response($arr, REST_Controller::HTTP_OK);
			
                return;
			}
		}
		
		 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}

	public function kegiatanpokok_get(){
		$headers = $this->input->request_headers();
	
			if (array_key_exists('Authorization', $headers) && !empty($headers['Authorization'])) {
				$decodedToken = AUTHORIZATION::validateToken($headers['Authorization']);
				
				if ($decodedToken != false) {
					$user_froup = $decodedToken->data->_pnc_id_grup;

					 $this->db->select(' kegiatan_pokok as nama');
					 $this->db->order_by('kegiatan_pokok','ASC');
					 $this->db->where('tampilkan','1');
					 if( ($user_froup =='1') OR  ($user_froup=='6')){
						 if(!empty($this->input->get('uk'))){
							$this->db->where('id_uk',$this->input->get('uk'));
						 }
					 	
					}else{
						$this->db->where('id_uk',$user_froup);
					}

					if(empty($this->input->get('tahun'))){
                        $this->db->where('tahun',date('Y'));
                    }else{
                        $this->db->where('tahun',$this->input->get('tahun'));
                    }
					 $this->db->group_by('kegiatan_pokok');
			  $res = $this->db->get('abk_beban_kerja')->result();
			  if(!empty($res)){
			  foreach($res as $d){
				$arr['result'][]=array('label'=>$d->nama,'value'=>$d->nama);
			  }
			}else{
				$arr[]='';
			}
			  $this->set_response($arr, REST_Controller::HTTP_OK);
				
					return;
				}
			}
			
			 $this->set_response("Unauthorised", REST_Controller::HTTP_UNAUTHORIZED);
	}
 
}