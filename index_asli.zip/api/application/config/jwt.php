<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['jwt_key']	= 'kerEnBanGet';

/* End of file jwt.php */
/* Location: ./application/config/jwt.php */